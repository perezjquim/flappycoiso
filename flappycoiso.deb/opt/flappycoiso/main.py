from ui.mainmenu import *

MainMenu()